import pickle


try:
    with open('cfr_data.pkl', 'rb') as f:
        data = pickle.load(f)
except EOFError:
    print("File is empty or corrupted.")
    data = None

