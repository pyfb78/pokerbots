import holdem_calc

print(holdem_calc.calculate(["As", "Ks", "Jd"], False, 10000, None, ["8s", "7s", "?", "?"], False))
